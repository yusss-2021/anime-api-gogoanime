# Anime API

Modified api of [Gogoanime-api](https://github.com/riimuru/gogoanime-api)

### Installing

Clone the Repository and run


```
git clone https://github.com/kirixenyt/anime-api.git
cd anime-api
npm install 
```
start the server with the following command:
```
npm start
```

Now the server is running on <a href="http://localhost:3000">http://localhost:3000</a>

### Render
Host your own api on render using the button below.

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/KirixenYT/anime-api)

### Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fkirixenyt%2Fanime-api)

[![Join our Discord server!](https://invidget.switchblade.xyz/BgTWqFnEss)](https://discord.gg/BgTWqFnEss)

